#!/usr/bin/env bash
set -euo pipefail
npm install
npx cap add android || true
npx cap sync android
