# Production integrations required
1. OTP: Firebase Auth / MSG91 / Twilio or another approved provider.
2. Database: PostgreSQL; run backend/schema.sql.
3. Mandi: connect an authoritative mandi-rate source/API and store source+timestamp.
4. Payments: authorised Indian payment gateway/marketplace payout flow; complete KYC and compliance before money movement.
5. Maps/delivery: Google Maps or Mapbox + delivery partner location/route APIs.
6. KYC: document upload/storage + admin verification workflow.
7. Export: IEC/GST/FSSAI/CHA/freight/document workflow as applicable; verify current requirements before each shipment.
8. Security: HTTPS, secrets in environment variables, rate limiting, audit logs, backups, role-based access.
