# Android / Play Store next steps
1. Install Node.js on a computer.
2. From this folder run `npm install`.
3. Run `npx cap add android`.
4. Run `npx cap sync`.
5. Open Android Studio with `npx cap open android`.
6. Test on a real Android phone.
7. Configure app icon, privacy policy, Data Safety, target SDK and signed release.
8. Build a signed AAB and upload it to Google Play Console.

A phone-only workflow will still need a cloud/PC build environment or an Android build service; the ZIP itself is source code, not a finished signed APK.
