# Kisan Bazaar V5 Final Unified Build

This package merges the V4 Phase 1 UI with the V4 Phase 2 A-F backend/API scaffold into one unified Android-ready project.

## Included modules
Farmer stock listing, buyer marketplace, buyer matching, bulk orders, international/export requirements, smart delivery route/status, mandi bhav UI, collection points, farmer products, OTP/login flow, orders, payment/commission ledger, KYC/verification, admin-ready PostgreSQL schema.

## Important
The project is production-structured but not a live marketplace yet. Demo fallbacks are intentionally present. Real OTP, authoritative live mandi data, payment/payout, maps, KYC storage and production PostgreSQL must be connected and tested before launch.

## Android
Use the project root package with Capacitor. Install Node.js, then `npm install`, `npx cap add android`, `npx cap sync`, and open Android Studio. Build a signed AAB for Google Play.
