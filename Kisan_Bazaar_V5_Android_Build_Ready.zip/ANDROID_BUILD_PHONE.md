# Kisan Bazaar V5 — Android Build from an Android phone

## 1. Put this project on GitHub
Create a new GitHub repository named `kisan-bazaar-v5` and upload all files from this folder.

## 2. Start the build
Open the repository on GitHub → **Actions** → **Kisan Bazaar Android Build** → **Run workflow**.

The workflow creates the Android project, syncs Capacitor, then builds:
- Debug APK: for installing/testing on your phone.
- Release AAB: unsigned; suitable as a build artifact, but Play Store publishing requires release signing.

## 3. Download APK
Actions → completed run → Artifacts → `kisan-bazaar-debug-apk` → download and extract `app-debug.apk`.

## 4. Play Store signing
For production publishing, create a private upload/release keystore and configure Gradle signing. Never commit the `.jks`/`.keystore` or passwords to GitHub. Store them in GitHub Actions Secrets.

Recommended application ID: `com.kisanbazaar.app`
App name: `Kisan Bazaar`
Version: `5.0.0`
